#include <iostream>

using namespace std;

int main(void){
    int N;

    cin >> N;

    int plug ;
    int total = 0;
    for(int i = 0 ; i < N; ++i){
        cin >> plug;
        total += plug;
    }
    
    total -= (N-1);

    cout << total;
}