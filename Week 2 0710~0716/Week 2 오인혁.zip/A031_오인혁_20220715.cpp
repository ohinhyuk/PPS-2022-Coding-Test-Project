// BaekJun 2163
// Title : 초콜릿
// URL : https://www.acmicpc.net/problem/2163

#include <iostream>

using namespace std;

int main(void){
    int N,M, cnt;

    cin >> N >> M;

    cnt = N*M - 1;

    cout << cnt;
}